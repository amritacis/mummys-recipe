<?php
include("header.php");
include("menu.php");
?>
<section class="page-title text-center" style="background-image: url(img/b-bg.jpg);">
    <div class="container">
        <div class="content-box">
            <div class="title">
                <h1> Blog</h1>
            </div>
            <ul class="bread-crumb clearfix">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item">Blog</li>
            </ul>
        </div>
    </div>
</section>

<!-- blog -->
<section class="blog py-4">
    <div class="container">
        
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-6">
                        <div class="item mb-5">
                            <div class="blog-img">
                                <img src="img/b1.jpg" alt="1000X1000" width="100%">
                            </div>

                            <h4 class="my-3">Excepteur sint occaecat cupidatat non proident</h4>
                            <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                            <div class="view-all">
                                <a href="single.php" class="view-btn-all">See More</a>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="item mb-5">
                            <div class="blog-img">
                                <img src="img/b1.jpg" alt="1000X1000" width="100%">
                            </div>
                            <h4 class="my-3">Excepteur sint occaecat cupidatat non proident</h4>
                            <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                            <div class="view-all">
                                <a href="single.php" class="view-btn-all">See More</a>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="item mb-5">
                            <div class="blog-img">
                                <img src="img/b1.jpg" alt="1000X1000" width="100%">
                            </div>
                            <h4 class="my-3">Excepteur sint occaecat cupidatat non proident</h4>
                            <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                            <div class="view-all">
                                <a href="single.php" class="view-btn-all">See More</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="sidebar right widget_area" role="complementary">
                    <div class="sidebar_inner">
                        <aside id="categories-2" class="widget widget_categories">
                            <h3 class="widget_title">Categories</h3>
                            <ul>
                                <li class="cat-item"><a href=""><i class="fa-solid fa-star"></i> Culture</a>
                                </li>
                                <li class="cat-item"><a href=""><i class="fa-solid fa-star"></i> Food Reviews</a>
                                </li>
                                <li class="cat-item"><a href=""><i class="fa-solid fa-star"></i> Streets &amp; Markets</a>
                                </li>
                                <li class="cat-item"><a aria-current="page" href=""><i class="fa-solid fa-star"></i> Traditional Mexican Food</a>
                                </li>
                                <li class="cat-item"><a href=""><i class="fa-solid fa-star"></i> Travel</a>
                                </li>
                            </ul>
                        </aside>

                        <aside id="widget_recent_news" class="widget widget_recent_news">
                            <h3 class="widget_title">Recent Posts</h3>
                            <div id="widget_recent" class="recent_news">
                                <article class="post_item">
                                    <div class="post_featured">
                                        <img width="270" height="152" src="img/b1.jpg">

                                    </div>
                                    <div class="post_header entry-header">
                                        <h6 class="post_title"><a href="" rel="bookmark">The Best tropical Cocktails in gustavo? Come Sip and Decide</a></h6>
                                    </div>
                                </article>
                                <article class="post_item">
                                    <div class="post_featured">
                                        <img width="270" height="152" src="img/b1.jpg">

                                    </div>
                                    <div class="post_header entry-header">
                                        <h6 class="post_title"><a href="" rel="bookmark">5 Reasons Why We’re the Most Instagrammable Restaurant</a></h6>
                                    </div>
                                </article>
                            </div>
                        </aside>
                        <aside id="tag" class="widget widget_tag_cloud">
                            <h3 class="widget_title">Tags</h3>
                            <div class="tagcloud">
                                <a href="" class="tag-link">Pickles,</a>
                                <a href="" class="tag-link">Mango Pickles,</a>
                                <a href="" class="tag-link">Lemon Pickles,</a>
                                <a href="" class="tag-link">Chilly Pickles,</a>

                                
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php include("footer.php"); ?>